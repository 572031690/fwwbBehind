create
    definer = root@localhost procedure proce_sb()
BEGIN
    insert into student valueS(null,'时迁',56,66,88);
    END;

