create
    definer = root@localhost procedure proce_sb1(IN sname varchar(10), IN chinese_sc int(10), IN math_sc int(10),
                                                 IN english_sc int(10))
BEGIN
    insert into student valueS(null,sname,chinese_sc,math_sc,english_sc);
    END;

