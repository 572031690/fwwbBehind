create view st as
select avg(`e`.`sal`) AS `avg(e.sal)`, count(`e`.`ename`) AS `count(e.ename)`, `d`.`dname` AS `dname`
from (`db01`.`newemp` `e`
         join `db01`.`dept` `d` on ((`e`.`deptId` = `d`.`deptId`)))
group by `e`.`deptId`;

