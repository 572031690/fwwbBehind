create definer = root@localhost view ywh as
select `e`.`empId` AS `empId`, `e`.`ename` AS `ename`, `e`.`sex` AS `sex`, `d`.`dname` AS `dname`
from (`db01`.`newemp` `e`
         join `db01`.`dept` `d` on ((`e`.`deptId` = `d`.`deptId`)))
where (`e`.`deptId` = 2);

